// ../core/src/filter.js
var TRACKING_PARAM_PREFIXES = ["utm_"];
var TRACKING_PARAM_NAMES = /* @__PURE__ */ new Set([
  "fbclid",
  "gclid",
  "dclid",
  "msclkid",
  "mc_eid",
  "mc_cid",
  "ref",
  "ref_src",
  "refsrc",
  "igshid",
  "igsh",
  "si",
  // YouTube/Spotify share-link id
  "_hsenc",
  "_hsmi",
  "vero_id",
  "yclid",
  "ocid",
  "spm",
  "WT.mc_id",
  "CMP"
]);
function isTrackingParam(name) {
  const lower = name.toLowerCase();
  if (TRACKING_PARAM_NAMES.has(lower)) return true;
  return TRACKING_PARAM_PREFIXES.some((prefix) => lower.startsWith(prefix));
}
function normalizeUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return url;
  }
  parsed.hash = "";
  parsed.hostname = parsed.hostname.toLowerCase();
  const keptParams = [...parsed.searchParams.entries()].filter(
    ([name]) => !isTrackingParam(name)
  );
  parsed.search = "";
  for (const [name, value] of keptParams) {
    parsed.searchParams.append(name, value);
  }
  let result = parsed.toString();
  if (parsed.pathname !== "/" && parsed.pathname.endsWith("/")) {
    const withoutTrailingSlash = parsed.pathname.replace(/\/+$/, "");
    parsed.pathname = withoutTrailingSlash === "" ? "/" : withoutTrailingSlash;
    result = parsed.toString();
  }
  return result;
}
var DEFAULT_EXCLUSIONS = [
  // -- Social feeds / messaging: infinite-scroll apps, not documents. A
  // "tab" here is a live session, not a piece of content worth an EPUB page.
  "linkedin.com",
  "facebook.com",
  "instagram.com",
  "x.com",
  "twitter.com",
  "threads.net",
  "tiktok.com",
  "reddit.com",
  // individual posts are fine via extraction, but the feed/home is not — see docs/interfaces.md extract gate for per-page quality scoring instead of a blanket exclude on submatches
  "web.whatsapp.com",
  "messenger.com",
  "discord.com",
  "slack.com",
  "telegram.org",
  // -- Webmail / productivity apps: session-based UI, never a static
  // article; also frequently contains sensitive personal data we should
  // never risk pulling into a digest.
  "mail.google.com",
  "docs.google.com",
  "drive.google.com",
  "calendar.google.com",
  "sheets.google.com",
  "slides.google.com",
  "outlook.com",
  "outlook.office.com",
  "outlook.office365.com",
  "notion.so",
  "trello.com",
  "asana.com",
  "linear.app",
  "jira.atlassian.com",
  "atlassian.net",
  // -- Streaming / media players: the tab is a video/audio player, not
  // readable text; extraction would either fail or produce garbage.
  "netflix.com",
  "youtube.com",
  "youtu.be",
  "hulu.com",
  "disneyplus.com",
  "spotify.com",
  "twitch.tv",
  "primevideo.com",
  // -- Code hosting / dev tool app pages: PR/issue/dashboard UI is
  // app-like, not an article. (READMEs and gists are borderline —
  // excluded by default; users can `kindling allow github.com` if they
  // specifically want repo docs in digests.)
  "github.com",
  "gitlab.com",
  "bitbucket.org",
  // -- Financial / checkout: never appropriate to snapshot or extract —
  // session-bound, sensitive, and explicitly a workflow, not content.
  "checkout.stripe.com",
  "paypal.com",
  "venmo.com",
  "chase.com",
  "bankofamerica.com",
  "wellsfargo.com",
  "amazon.com",
  // cart/order pages — product pages aren't "articles" either
  "accounts.google.com",
  // -- Search results / app shells: a search results page or account
  // console is a UI, not a document to read.
  "google.com",
  "accounts.youtube.com"
];
var BANK_HOST_PATTERN = /bank/i;
function isBankHost(hostname) {
  return BANK_HOST_PATTERN.test(hostname);
}
function stripIpv6Brackets(hostname) {
  return hostname.startsWith("[") && hostname.endsWith("]") ? hostname.slice(1, -1) : hostname;
}
function isLocalHost(hostname) {
  const h = stripIpv6Brackets(hostname);
  if (h === "localhost" || h === "127.0.0.1" || h === "::1") return true;
  if (h.endsWith(".local")) return true;
  return false;
}
function isPrivateIpv4(o1, o2) {
  if (o1 === 0) return true;
  if (o1 === 10) return true;
  if (o1 === 127) return true;
  if (o1 === 172 && o2 >= 16 && o2 <= 31) return true;
  if (o1 === 192 && o2 === 168) return true;
  if (o1 === 169 && o2 === 254) return true;
  return false;
}
function isPrivateOrLinkLocalIp(hostname) {
  const h = stripIpv6Brackets(hostname).toLowerCase();
  const ipv4 = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (ipv4) {
    const [o1, o2] = ipv4.slice(1).map(Number);
    return isPrivateIpv4(o1, o2);
  }
  const mappedDotted = h.match(
    /::ffff:(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/
  );
  if (mappedDotted) {
    const [o1, o2] = mappedDotted.slice(1).map(Number);
    return isPrivateIpv4(o1, o2);
  }
  const mappedHex = h.match(/::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (mappedHex) {
    const hi = parseInt(mappedHex[1], 16);
    const o1 = hi >> 8 & 255;
    const o2 = hi & 255;
    return isPrivateIpv4(o1, o2);
  }
  if (h.startsWith("fe80:")) return true;
  if (/^f[cd][0-9a-f]{2}:/.test(h)) return true;
  return false;
}
function hostMatchesDomain(hostname, domain) {
  const h = hostname.toLowerCase();
  const d = domain.toLowerCase();
  return h === d || h.endsWith("." + d);
}
function matchesAnyDomain(hostname, domains) {
  return domains.some((domain) => hostMatchesDomain(hostname, domain));
}
function screenUrl(url, rules = {}) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return { include: false, reason: "not a web page" };
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    return { include: false, reason: "not a web page" };
  }
  const hostname = parsed.hostname.replace(/\.$/, "");
  if (isLocalHost(hostname) || isPrivateOrLinkLocalIp(hostname)) {
    return { include: false, reason: "local/private address" };
  }
  const allow = rules.allow || [];
  if (matchesAnyDomain(hostname, allow)) {
    return { include: true, reason: "allowed by user rule" };
  }
  if (isBankHost(hostname)) {
    return { include: false, reason: "excluded domain: banking site" };
  }
  const block = [...DEFAULT_EXCLUSIONS, ...rules.block || []];
  const matched = block.find((domain) => hostMatchesDomain(hostname, domain));
  if (matched) {
    return { include: false, reason: `excluded domain: ${matched}` };
  }
  return { include: true, reason: "ok" };
}

// src/adapters.js
var chromeStorage = {
  async get(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  },
  async set(key, value) {
    await chrome.storage.local.set({ [key]: value });
  },
  async remove(key) {
    await chrome.storage.local.remove(key);
  }
};
var DEFAULT_CONFIG = {
  kindleEmail: "",
  senderEmail: "",
  staleHours: 48,
  minWords: 300,
  filters: { block: [], allow: [] },
  disableWayback: false,
  llm: null,
  // Bring-your-own Google OAuth client id — enables the launchWebAuthFlow
  // send path on Edge/Firefox and past the shared client's ~100-user cap.
  // Empty → use Chrome's native shared-client flow.
  oauthClientId: ""
};
async function loadConfig() {
  const stored = await chromeStorage.get("config") || {};
  return {
    ...DEFAULT_CONFIG,
    ...stored,
    filters: { ...DEFAULT_CONFIG.filters, ...stored.filters || {} }
  };
}
async function findOpenTab(url) {
  const target = normalizeUrl(url);
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!tab.url || tab.id == null) continue;
    if (normalizeUrl(tab.url) === target) return tab;
  }
  return null;
}
function readExtractResult(minWords) {
  window.__kindlingMinWords = minWords;
  return window.__kindlingExtract ? window.__kindlingExtract() : { status: "failed", reason: "content-extract.js did not load" };
}
function makeContentSource() {
  return {
    async getArticle(url, opts = {}) {
      try {
        const tab = await findOpenTab(url);
        if (!tab) {
          return { status: "skipped", reason: "tab not open" };
        }
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content-extract.js"]
        });
        const minWords = typeof opts.minWords === "number" ? opts.minWords : 300;
        const [injection] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: readExtractResult,
          args: [minWords]
        });
        const result = injection && injection.result;
        if (!result) {
          return { status: "failed", reason: "no result from content-extract" };
        }
        return result;
      } catch (err) {
        return { status: "failed", reason: `injection failed: ${err && err.message}` };
      }
    }
  };
}

// src/background.js
var TAB_AGES_KEY = "tabAges";
var RECOMPUTE_ALARM = "recompute";
var SCHEDULED_SEND_ALARM = "scheduled-send";
var RECOMPUTE_PERIOD_MINUTES = 30;
var OFFSCREEN_URL = "offscreen/offscreen.html";
var BADGE_COLOR = "#D97706";
async function recomputeTabAges() {
  const config = await loadConfig();
  const tabs = await chrome.tabs.query({});
  const nowIso = (/* @__PURE__ */ new Date()).toISOString();
  const tabAges = await chromeStorage.get(TAB_AGES_KEY) || {};
  const seen = /* @__PURE__ */ new Set();
  for (const tab of tabs) {
    if (!tab.url || !/^https?:/i.test(tab.url)) continue;
    const { include } = screenUrl(tab.url, config.filters);
    if (!include) continue;
    const key = normalizeUrl(tab.url);
    seen.add(key);
    const existing = tabAges[key];
    if (!existing) {
      tabAges[key] = { firstSeen: nowIso, title: tab.title || tab.url, url: tab.url };
    } else {
      existing.title = tab.title || existing.title;
      existing.url = tab.url;
    }
  }
  for (const key of Object.keys(tabAges)) {
    if (!seen.has(key)) delete tabAges[key];
  }
  await chromeStorage.set(TAB_AGES_KEY, tabAges);
  await updateBadge(config, tabAges);
  return tabAges;
}
async function updateBadge(config, tabAges) {
  const staleHours = config.staleHours ?? 48;
  const thresholdMs = staleHours * 60 * 60 * 1e3;
  const nowMs = Date.now();
  let staleCount = 0;
  for (const record of Object.values(tabAges)) {
    if (nowMs - new Date(record.firstSeen).getTime() >= thresholdMs) staleCount++;
  }
  await chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR });
  await chrome.action.setBadgeText({ text: staleCount > 0 ? String(staleCount) : "" });
}
function tabsFromAges(tabAges, staleHours) {
  const thresholdMs = (staleHours ?? 48) * 60 * 60 * 1e3;
  const nowMs = Date.now();
  return Object.values(tabAges).map((record) => {
    const ageMs = nowMs - new Date(record.firstSeen).getTime();
    return { url: record.url, title: record.title, ageMs, stale: ageMs >= thresholdMs };
  });
}
for (const evt of [chrome.tabs.onCreated, chrome.tabs.onRemoved]) {
  evt.addListener(() => {
    recomputeTabAges().catch((err) => console.error("kindling: recompute failed", err));
  });
}
chrome.tabs.onUpdated.addListener((_tabId, changeInfo) => {
  if (!changeInfo.url && changeInfo.status !== "complete") return;
  recomputeTabAges().catch((err) => console.error("kindling: recompute failed", err));
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === RECOMPUTE_ALARM) {
    recomputeTabAges().catch((err) => console.error("kindling: recompute failed", err));
  } else if (alarm.name === SCHEDULED_SEND_ALARM) {
    runScheduledSend().catch((err) => console.error("kindling: scheduled send failed", err));
  }
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(RECOMPUTE_ALARM, { periodInMinutes: RECOMPUTE_PERIOD_MINUTES });
  recomputeTabAges().catch((err) => console.error("kindling: recompute failed", err));
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(RECOMPUTE_ALARM, { periodInMinutes: RECOMPUTE_PERIOD_MINUTES });
  recomputeTabAges().catch((err) => console.error("kindling: recompute failed", err));
});
var offscreenReady = null;
async function hasOffscreenDocument() {
  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)]
    });
    return contexts.length > 0;
  }
  return false;
}
async function ensureOffscreenDocument() {
  if (await hasOffscreenDocument()) return;
  if (offscreenReady) return offscreenReady;
  offscreenReady = chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ["DOM_PARSER"],
    justification: "build the EPUB digest"
  }).catch((err) => {
    if (!/single offscreen document/i.test(String(err && err.message))) throw err;
  }).finally(() => {
    offscreenReady = null;
  });
  return offscreenReady;
}
async function closeOffscreenDocument() {
  if (await hasOffscreenDocument()) {
    await chrome.offscreen.closeDocument();
  }
}
async function runScheduledSend() {
  const config = await loadConfig();
  if (!config.kindleEmail) return;
  await ensureOffscreenDocument();
  try {
    const report = await chrome.runtime.sendMessage({ type: "RUN_SCHEDULED" });
    return report;
  } finally {
    await closeOffscreenDocument().catch((err) => console.error("kindling: closing offscreen failed", err));
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!sender || sender.id !== chrome.runtime.id) return false;
  if (!message || typeof message.type !== "string") return false;
  handleMessage(message, sender).then(sendResponse).catch((err) => sendResponse({ error: String(err && err.message || err) }));
  return true;
});
async function handleMessage(message) {
  switch (message.type) {
    case "GET_STATE": {
      const config = await loadConfig();
      const tabAges = await chromeStorage.get(TAB_AGES_KEY) || {};
      return { config, tabs: tabsFromAges(tabAges, config.staleHours) };
    }
    case "SET_CONFIG": {
      await chromeStorage.set("config", message.config);
      await recomputeTabAges();
      return { ok: true };
    }
    case "SCHEDULE_INSTALL": {
      const periodInMinutes = Math.max(1, Number(message.everyMinutes) || 60);
      await chrome.alarms.create(SCHEDULED_SEND_ALARM, { periodInMinutes });
      return { ok: true };
    }
    case "SCHEDULE_UNINSTALL": {
      await chrome.alarms.clear(SCHEDULED_SEND_ALARM);
      return { ok: true };
    }
    case "EXTRACT": {
      const source = makeContentSource();
      return source.getArticle(message.url, message.opts || {});
    }
    default:
      return { error: `unknown message type: ${message.type}` };
  }
}
