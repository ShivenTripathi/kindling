// src/adapters.js
var chromeStorage = {
  async get(key) {
    const result = await chrome.storage.local.get(key);
    return result[key];
  },
  async set(key, value) {
    await chrome.storage.local.set({ [key]: value });
  },
  async remove(key) {
    await chrome.storage.local.remove(key);
  }
};
var DEFAULT_CONFIG = {
  kindleEmail: "",
  senderEmail: "",
  staleHours: 48,
  minWords: 300,
  filters: { block: [], allow: [] },
  disableWayback: false,
  llm: null,
  // Bring-your-own Google OAuth client id — enables the launchWebAuthFlow
  // send path on Edge/Firefox and past the shared client's ~100-user cap.
  // Empty → use Chrome's native shared-client flow.
  oauthClientId: ""
};
async function loadConfig() {
  const stored = await chromeStorage.get("config") || {};
  return {
    ...DEFAULT_CONFIG,
    ...stored,
    filters: { ...DEFAULT_CONFIG.filters, ...stored.filters || {} }
  };
}
async function saveConfig(cfg) {
  await chromeStorage.set("config", cfg);
}
var GMAIL_SEND_SCOPE = "https://www.googleapis.com/auth/gmail.send";
var USERINFO_EMAIL_SCOPE = "https://www.googleapis.com/auth/userinfo.email";
var SCOPES = [GMAIL_SEND_SCOPE, USERINFO_EMAIL_SCOPE];
var webAuthCache = { token: "", expiresAt: 0 };
async function getAuthToken(interactive = true) {
  const config2 = await loadConfig();
  const byoClientId = config2.oauthClientId && String(config2.oauthClientId).trim();
  const nativeAvailable = typeof chrome !== "undefined" && chrome.identity && typeof chrome.identity.getAuthToken === "function";
  if (nativeAvailable && !byoClientId) {
    return getAuthTokenNative(interactive);
  }
  return getAuthTokenWebFlow(byoClientId, interactive);
}
function getAuthTokenNative(interactive) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive, scopes: SCOPES }, (tokenResult) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      const token = typeof tokenResult === "string" ? tokenResult : tokenResult && tokenResult.token;
      if (!token) {
        reject(new Error("no auth token returned"));
        return;
      }
      resolve(token);
    });
  });
}
async function getAuthTokenWebFlow(clientId, interactive) {
  const now = Date.now();
  if (webAuthCache.token && webAuthCache.expiresAt - 6e4 > now) {
    return webAuthCache.token;
  }
  if (!clientId) {
    throw new Error(
      "This browser needs a bring-your-own Google client: set an OAuth client ID in Kindling's settings (see the extension README)."
    );
  }
  const redirectUri = chrome.identity.getRedirectURL();
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(clientId)}&response_type=token&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent(SCOPES.join(" "))}&prompt=consent`;
  const redirectUrl = await new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({ url: authUrl, interactive }, (out) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!out) {
        reject(new Error("authorization was cancelled"));
        return;
      }
      resolve(out);
    });
  });
  const fragment = String(redirectUrl).split("#")[1] || "";
  const params = new URLSearchParams(fragment);
  const token = params.get("access_token");
  if (!token) throw new Error("no access token in the OAuth redirect");
  const expiresIn = Number(params.get("expires_in") || 3600) * 1e3;
  webAuthCache = { token, expiresAt: Date.now() + expiresIn };
  return token;
}
async function getAuthEmail() {
  const token = await getAuthToken(false);
  const res = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) return null;
  const info = await res.json();
  return info.email || null;
}

// src/options/options.js
var $ = (id) => document.getElementById(id);
var els = {
  dashboardLink: $("dashboard-link"),
  form: $("settings-form"),
  kindleEmail: $("kindle-email"),
  senderEmail: $("sender-email"),
  reconnectGoogle: $("reconnect-google"),
  staleHours: $("stale-hours"),
  scheduleEnabled: $("schedule-enabled"),
  scheduleMinutes: $("schedule-minutes"),
  scheduleIntervalField: $("schedule-interval-field"),
  blockList: $("block-list"),
  allowList: $("allow-list"),
  disableWayback: $("disable-wayback"),
  llmProvider: $("llm-provider"),
  llmGeminiNote: $("llm-gemini-note"),
  llmApiKey: $("llm-api-key"),
  llmBaseUrlField: $("llm-base-url-field"),
  llmBaseUrl: $("llm-base-url"),
  llmModel: $("llm-model"),
  saveBtn: $("save-btn"),
  savedConfirmation: $("saved-confirmation"),
  saveError: $("save-error")
};
var DEFAULT_SCHEDULE_MINUTES = 360;
var MODEL_PLACEHOLDER = {
  gemini: "gemini-2.5-flash-lite",
  anthropic: "claude-3-5-haiku-latest",
  "openai-compatible": "gpt-4o-mini"
};
var config = null;
els.dashboardLink.addEventListener(
  "click",
  () => chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/dashboard.html") })
);
init();
async function init() {
  config = await loadConfig();
  populateForm(config);
  updateScheduleFieldVisibility();
}
function populateForm(cfg) {
  els.kindleEmail.value = cfg.kindleEmail || "";
  els.senderEmail.value = cfg.senderEmail || "";
  els.staleHours.value = cfg.staleHours ?? 48;
  els.scheduleEnabled.checked = !!cfg.scheduleEnabled;
  els.scheduleMinutes.value = cfg.scheduleMinutes || DEFAULT_SCHEDULE_MINUTES;
  const filters = cfg.filters || {};
  els.blockList.value = (filters.block || []).join("\n");
  els.allowList.value = (filters.allow || []).join("\n");
  els.disableWayback.checked = !!cfg.disableWayback;
  const llm = cfg.llm || {};
  els.llmProvider.value = llm.provider || "gemini";
  els.llmApiKey.value = llm.apiKey || "";
  els.llmBaseUrl.value = llm.baseUrl || "";
  els.llmModel.value = llm.model || "";
  updateLlmFieldVisibility();
}
function updateScheduleFieldVisibility() {
  els.scheduleIntervalField.style.display = els.scheduleEnabled.checked ? "" : "none";
}
function updateLlmFieldVisibility() {
  const provider = els.llmProvider.value;
  els.llmBaseUrlField.style.display = provider === "openai-compatible" ? "" : "none";
  els.llmGeminiNote.style.display = provider === "gemini" ? "" : "none";
  els.llmModel.placeholder = MODEL_PLACEHOLDER[provider] || "";
}
els.scheduleEnabled.addEventListener("change", updateScheduleFieldVisibility);
els.llmProvider.addEventListener("change", updateLlmFieldVisibility);
els.reconnectGoogle.addEventListener("click", async () => {
  els.reconnectGoogle.disabled = true;
  const original = els.reconnectGoogle.textContent;
  els.reconnectGoogle.textContent = "Connecting\u2026";
  try {
    await getAuthToken(true);
    const email = await getAuthEmail();
    if (email) els.senderEmail.value = email;
    showSaveError("");
  } catch (err) {
    showSaveError(`Couldn't connect to Google: ${err && err.message || err}`);
  } finally {
    els.reconnectGoogle.disabled = false;
    els.reconnectGoogle.textContent = original;
  }
});
function parseDomainList(text) {
  return text.split("\n").map((line) => line.trim().toLowerCase()).filter(Boolean);
}
function isValidKindleEmail(value) {
  return /^[^\s@]+@(free\.)?kindle\.com$/.test(value.trim().toLowerCase());
}
els.form.addEventListener("submit", async (e) => {
  e.preventDefault();
  showSaveError("");
  els.savedConfirmation.hidden = true;
  const kindleEmail = els.kindleEmail.value.trim().toLowerCase();
  if (kindleEmail && !isValidKindleEmail(kindleEmail)) {
    showSaveError("The Kindle address should end in kindle.com or free.kindle.com.");
    els.kindleEmail.focus();
    return;
  }
  const staleHours = Number(els.staleHours.value);
  if (!Number.isFinite(staleHours) || staleHours <= 0) {
    showSaveError("\u201CSend after\u201D must be a positive number of hours.");
    els.staleHours.focus();
    return;
  }
  const scheduleEnabled = els.scheduleEnabled.checked;
  const scheduleMinutes = Number(els.scheduleMinutes.value) || DEFAULT_SCHEDULE_MINUTES;
  if (scheduleEnabled && scheduleMinutes < 15) {
    showSaveError("The schedule interval must be at least 15 minutes.");
    els.scheduleMinutes.focus();
    return;
  }
  const apiKey = els.llmApiKey.value.trim();
  const llmProvider = els.llmProvider.value;
  if (apiKey && llmProvider === "openai-compatible" && !els.llmBaseUrl.value.trim()) {
    showSaveError("The OpenAI-compatible provider needs a base URL (e.g. https://api.openai.com/v1).");
    els.llmBaseUrl.focus();
    return;
  }
  const llm = apiKey ? {
    provider: llmProvider,
    apiKey,
    baseUrl: els.llmBaseUrl.value.trim() || void 0,
    model: els.llmModel.value.trim() || void 0
  } : null;
  const next = {
    ...config,
    kindleEmail,
    senderEmail: els.senderEmail.value.trim(),
    staleHours,
    scheduleEnabled,
    scheduleMinutes,
    filters: {
      block: parseDomainList(els.blockList.value),
      allow: parseDomainList(els.allowList.value)
    },
    disableWayback: els.disableWayback.checked,
    llm
  };
  els.saveBtn.disabled = true;
  els.saveBtn.textContent = "Saving\u2026";
  try {
    await saveConfig(next);
    await chrome.runtime.sendMessage({ type: "SET_CONFIG", config: next }).catch(() => {
    });
    if (scheduleEnabled) {
      await chrome.runtime.sendMessage({ type: "SCHEDULE_INSTALL", everyMinutes: scheduleMinutes });
    } else {
      await chrome.runtime.sendMessage({ type: "SCHEDULE_UNINSTALL" });
    }
    config = next;
    els.savedConfirmation.hidden = false;
    window.clearTimeout(showSaveError._t);
    showSaveError._t = window.setTimeout(() => {
      els.savedConfirmation.hidden = true;
    }, 2500);
  } catch (err) {
    showSaveError(`Couldn't save: ${err && err.message || err}`);
  } finally {
    els.saveBtn.disabled = false;
    els.saveBtn.textContent = "Save settings";
  }
});
function showSaveError(message) {
  if (!message) {
    els.saveError.hidden = true;
    els.saveError.textContent = "";
    return;
  }
  els.saveError.hidden = false;
  els.saveError.textContent = message;
}
